#!/usr/bin/with-contenv bashio
echo "Starting ora2mqtt..."
exec dotnet /app/Ora2Mqtt.dll