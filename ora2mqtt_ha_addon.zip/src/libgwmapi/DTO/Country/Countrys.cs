﻿using System.Text.Json.Serialization;

namespace libgwmapi.DTO.Country
{
    public class Countrys
    {
        [JsonPropertyName("A")]
        public Country[] A { get; set; }

        [JsonPropertyName("B")]
        public Country[] B { get; set; }

        [JsonPropertyName("C")]
        public Country[] C { get; set; }

        [JsonPropertyName("D")]
        public Country[] D { get; set; }

        [JsonPropertyName("E")]
        public Country[] E { get; set; }

        [JsonPropertyName("F")]
        public Country[] F { get; set; }

        [JsonPropertyName("G")]
        public Country[] G { get; set; }

        [JsonPropertyName("H")]
        public Country[] H { get; set; }

        [JsonPropertyName("I")]
        public Country[] I { get; set; }

        [JsonPropertyName("J")]
        public Country[] J { get; set; }

        [JsonPropertyName("K")]
        public Country[] K { get; set; }

        [JsonPropertyName("L")]
        public Country[] L { get; set; }

        [JsonPropertyName("M")]
        public Country[] M { get; set; }

        [JsonPropertyName("N")]
        public Country[] N { get; set; }

        [JsonPropertyName("O")]
        public Country[] O { get; set; }

        [JsonPropertyName("P")]
        public Country[] P { get; set; }

        [JsonPropertyName("Q")]
        public Country[] Q { get; set; }

        [JsonPropertyName("R")]
        public Country[] R { get; set; }

        [JsonPropertyName("S")]
        public Country[] S { get; set; }

        [JsonPropertyName("T")]
        public Country[] T { get; set; }

        [JsonPropertyName("U")]
        public Country[] U { get; set; }

        [JsonPropertyName("V")]
        public Country[] V { get; set; }

        [JsonPropertyName("W")]
        public Country[] W { get; set; }

        [JsonPropertyName("X")]
        public Country[] X { get; set; }

        [JsonPropertyName("Y")]
        public Country[] Y { get; set; }

        [JsonPropertyName("Z")]
        public Country[] Z { get; set; }
    }
}
